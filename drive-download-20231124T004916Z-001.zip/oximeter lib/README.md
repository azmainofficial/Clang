<a href="https://youtu.be/KarBC2ZKpBY">
<img src="https://dkardu.oss-cn-hongkong.aliyuncs.com/xueyangnew/xueyangnewytb.jpg" /> 
</a></br>

UPGRADED VERSION!</br>
In this project we only use the max30102 heart rate blood oxygen sensor module. Max30102 integrates a red LED and infrared LED, photodetector, optical device, and low-noise electronic circuit with ambient light suppression. </br>
In the project, when you measure your heart rate and blood oxygen concentration, press the button and your current heart rate and blood oxygen concentration will appear on the OLED screen.</br></br>

Happy New Year and Have fun with it.
</br></br>

► Code in GitHub (scheme and sketch): https://github.com/DKARDU/heartrateNbloodoxygen</br></br>

► Components</br>
The following parts were used in this project:</br>
Arduino NANO, https://amzn.to/3ihYFBl</br>
0.96" I2C OLED, https://amzn.to/3gTMZnW</br>
Max30102 Heart Rate Sensor</br>
Jumper wires, https://amzn.to/3jCHhZd</br>
Breadboard, https://amzn.to/33yEavN</br>
</br></br></br>


❤Subscribe It's Free https://bit.ly/2C6HdAg </br></br>

Thanks for watching, Stay home and Be safe...Have a great day!</br>
#Arduinoproject #ArduinoBloodOxygen #Howto #COVID19 #BloodOxygen #ArduinoHeartRate #HeartRate</br></br>


<img src="https://dkardu.oss-cn-hongkong.aliyuncs.com/xueyangnew/%E7%94%B5%E8%B7%AF%E5%9B%BE.jpg" /></br>

<img src="https://dkardu.oss-cn-hongkong.aliyuncs.com/xueyangnew/01.png" /></br>
<img src="https://dkardu.oss-cn-hongkong.aliyuncs.com/xueyangnew/02.png" /></br>
<img src="https://dkardu.oss-cn-hongkong.aliyuncs.com/xueyangnew/03.png" /></br>
